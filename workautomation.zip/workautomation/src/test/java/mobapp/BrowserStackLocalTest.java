package mobapp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.browserstack.local.Local;

public class BrowserStackLocalTest {
   
	public static final String USERNAME = "vinothinidhanase_tjhzrs";
    public static final String AUTOMATE_KEY = "Shg9bXPsGxGkpgrQMdZ3";
    

    public static void main(String[] args) throws Exception {
		
        Local local = new Local();
        DesiredCapabilities caps = new DesiredCapabilities();

        caps.setCapability("browserName", "android");
        caps.setCapability("device", "Samsung Galaxy S21");
        caps.setCapability("realMobile", "true");
        caps.setCapability("os_version", "12.0");
        caps.setCapability("app", "bs://aa6dd82fe35dc21ba708d0429a9290053b5f9852");

        local.start(new HashMap<String, String>() {
            {
                put("key", AUTOMATE_KEY);
            }
        });

        WebDriver driver = new RemoteWebDriver(new URL("http://" + USERNAME + ":" + AUTOMATE_KEY
                + "@hub.browserstack.com/wd/hub"), caps);
       
/*
       List<WebElement> textElements =driver.findElements(By.xpath("//android.widget.TextView"));
        List<String> textvalues= new ArrayList<>();
		
		for(WebElement element : textElements)	{
			 String text = element.getText();
			textvalues.add(text);
		}

		for(String text: textvalues) {
			System.out.println(text);
			
		}
		*/
        List<String> notepadTextValues = readTextValuesFromNotepad("D:/AUTOMATION/test.txt");

    
        List<WebElement> appElements  =driver.findElements(By.xpath("//android.widget.TextView"));

        
        for (int i = 0; i < notepadTextValues.size(); i++) {
            String notepadText1 = notepadTextValues.get(i);
            String appText = appElements.get(i).getText();

            if (notepadText1.equals(appText)) {
                System.out.println("Text values match: " + notepadText1);
            } else {
                System.out.println("Text values do not match: " + notepadText1 + " vs " + appText);
            }
        }


        driver.quit();
        local.stop();
    }
    
    private static List<String> readTextValuesFromNotepad(String filePath) {
        List<String> textValues = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                textValues.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return textValues;
    }
}